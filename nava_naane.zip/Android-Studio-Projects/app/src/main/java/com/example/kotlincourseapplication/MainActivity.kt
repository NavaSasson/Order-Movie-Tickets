package com.example.kotlincourseapplication

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import android.webkit.WebView
import android.widget.Button
import android.widget.DatePicker
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale


class MainActivity : AppCompatActivity() {
    @SuppressLint("SetJavaScriptEnabled", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.my_layout)

        val autoCompleteTextViewKids = findViewById<AutoCompleteTextView>(R.id.child_text_field)
        val listItems = listOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
        val arrayAdapterChild = ArrayAdapter(this, android.R.layout.simple_spinner_item, listItems)
        var selectedItemChild = 0

        arrayAdapterChild.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        autoCompleteTextViewKids.setAdapter(arrayAdapterChild)

        autoCompleteTextViewKids.setOnItemClickListener { _, _, position, _ ->
            selectedItemChild = listItems[position]
            Toast.makeText(
                this@MainActivity,
                getString(R.string.toast_tickets_message) + selectedItemChild.toString(),
                Toast.LENGTH_SHORT
            ).show()
        }

        val autoCompleteTextViewAdult = findViewById<AutoCompleteTextView>(R.id.adult_text_field)
        val arrayAdapterAdult = ArrayAdapter(this, android.R.layout.simple_spinner_item, listItems)
        var selectedItemAdult = 0

        arrayAdapterAdult.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        autoCompleteTextViewAdult.setAdapter(arrayAdapterAdult) // Set adapter to the AutoCompleteTextView

        autoCompleteTextViewAdult.setOnItemClickListener { _, _, position, _ ->
            selectedItemAdult = listItems[position]
            Toast.makeText(
                this@MainActivity,
                getString(R.string.toast_tickets_message) + selectedItemAdult.toString(),
                Toast.LENGTH_SHORT
            ).show()
        }

        val customBtn = findViewById<MaterialButton>(R.id.trailer_btn)
        customBtn.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            val dialogView = layoutInflater.inflate(R.layout.trailer_custom_dialog, null)
            val materialButton = dialogView.findViewById<MaterialButton>(R.id.exit_button)
            val webView = dialogView.findViewById<WebView>(R.id.web_view)

            builder.setView(dialogView)
            val dialog = builder.create()

            webView.settings.javaScriptEnabled = true
            webView.loadUrl("https://www.youtube.com/embed/UcjYD91YW_M?si=g_K4g0bbEJUnucWy")

            materialButton.setOnClickListener {
                dialog.dismiss()
            }
            dialog.show()
        }


        val bottomSheetDialog = BottomSheetDialog(this)
        bottomSheetDialog.setContentView(R.layout.gallery_bottom_sheet_dialog)

        val exitBtn = bottomSheetDialog.findViewById<MaterialButton>(R.id.exit_button)
        exitBtn?.setOnClickListener {
            bottomSheetDialog.dismiss()
        }

        val largeImage =  bottomSheetDialog.findViewById<ImageView>(R.id.image_view_center)

        bottomSheetDialog.findViewById<ImageView>(R.id.image_view_anastasia)?.setOnClickListener{
            largeImage?.setImageResource(R.drawable.anastasia)
        }

        bottomSheetDialog.findViewById<ImageView>(R.id.image_view_cinder)?.setOnClickListener{
            largeImage?.setImageResource(R.drawable.cinder)
        }

        bottomSheetDialog.findViewById<ImageView>(R.id.image_view_drizella)?.setOnClickListener{
            largeImage?.setImageResource(R.drawable.drizella)
        }

        bottomSheetDialog.findViewById<ImageView>(R.id.image_view_fairy_godmother)?.setOnClickListener{
            largeImage?.setImageResource(R.drawable.fairy_godmother)
        }

        bottomSheetDialog.findViewById<ImageView>(R.id.image_view_luzifer)?.setOnClickListener{
            largeImage?.setImageResource(R.drawable.luzifer)
        }

        bottomSheetDialog.findViewById<ImageView>(R.id.image_view_mouse)?.setOnClickListener{
            largeImage?.setImageResource(R.drawable.mouse)
        }

        bottomSheetDialog.findViewById<ImageView>(R.id.image_view_prince)?.setOnClickListener{
            largeImage?.setImageResource(R.drawable.prince)
        }

        bottomSheetDialog.findViewById<ImageView>(R.id.image_view_step_mother)?.setOnClickListener{
            largeImage?.setImageResource(R.drawable.step_mother)
        }
        val galleryBtn =  findViewById<MaterialButton>(R.id.gallery_btn)
        galleryBtn.setOnClickListener{
            bottomSheetDialog.show()
        }

        val cinemaText = findViewById<TextView>(R.id.cinema_text)
        val cinemaCustomBtn = findViewById<MaterialButton>(R.id.cinema_btn)
        cinemaCustomBtn.setOnClickListener {

            val cinemaBuilder = AlertDialog.Builder(this)
            val cinemaDialogView = layoutInflater.inflate(R.layout.cinema_custom_dialog, null)

            cinemaBuilder.setView(cinemaDialogView)
            val cinemaDialog = cinemaBuilder.create()
            cinemaDialogView.findViewById<RadioGroup>(R.id.radio_group)?.setOnCheckedChangeListener{ group, checkedID ->
                val radioBtn1 = group.findViewById<RadioButton>(R.id.radio_btn1)
                val radioBtn2 = group.findViewById<RadioButton>(R.id.radio_btn2)
                val radioBtn3 = group.findViewById<RadioButton>(R.id.radio_btn3)
                val radioBtn4 = group.findViewById<RadioButton>(R.id.radio_btn4)

                when (checkedID) {
                    R.id.radio_btn1 -> cinemaText.text = radioBtn1.text
                    R.id.radio_btn2 -> cinemaText.text = radioBtn2.text
                    R.id.radio_btn3 -> cinemaText.text = radioBtn3.text
                    R.id.radio_btn4 -> cinemaText.text = radioBtn4.text
                }
            }

            val okBtn = cinemaDialogView.findViewById<MaterialButton>(R.id.ok_button)
            okBtn?.setOnClickListener {
                cinemaDialog.dismiss()
            }
            cinemaDialog.show()
        }

        val dateText = findViewById<TextView>(R.id.date_text)
        val dateBtn = findViewById<MaterialButton>(R.id.date_btn)
        dateBtn.setOnClickListener {
            val calendar = Calendar.getInstance()
            val minDate = calendar.timeInMillis
            val listener = DatePickerDialog.OnDateSetListener { _: DatePicker?, year: Int, month: Int, dayOfMonth: Int ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(year, month, dayOfMonth)
                val formattedDate = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(selectedDate.time)
                Toast.makeText(this, getString(R.string.selected_date) + formattedDate, Toast.LENGTH_SHORT).show()
                dateText.text = formattedDate
            }

            val datePickerDialog = DatePickerDialog(this, listener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))

            datePickerDialog.datePicker.minDate = minDate
            datePickerDialog.show()
        }

        val animation = AnimationUtils.loadAnimation(applicationContext, R.anim.animation)
        val getTicketsBtn = findViewById<Button>(R.id.get_tickets_btn)
        getTicketsBtn.startAnimation(animation)

        getTicketsBtn.setOnClickListener{
            if (dateText.text == getString(R.string.not_selected_a_date_yet) ||
                cinemaText.text == getString(R.string.cinema_text) ||
                (selectedItemChild == 0 && selectedItemAdult == 0))
            {
                val builder : AlertDialog.Builder = AlertDialog.Builder(this)
                builder.apply {
                    setTitle(getString(R.string.alert_title))
                    setMessage(getString(R.string.alert_message))
                    setCancelable(false)
                    setIcon(R.drawable.baseline_exit_to_app_24)
                    setPositiveButton(R.string.ok1){ _, _ ->

                    }
                    val dialog = builder.create()
                    dialog.show()
                }
            }
            else{
                    val getTicketsBuilder = AlertDialog.Builder(this)
                    val getTicketsDialogView = layoutInflater.inflate(R.layout.get_tickets_dialog, null)
                    getTicketsBuilder.setView(getTicketsDialogView)
                    val getTicketsDialog = getTicketsBuilder.create()

                    val adultTicketsTextView = getTicketsDialogView.findViewById<TextView>(R.id.message2_text)
                    val childTicketsTextView = getTicketsDialogView.findViewById<TextView>(R.id.message3_text)
                    val cinemaTextView = getTicketsDialogView.findViewById<TextView>(R.id.message4_text)
                    val dateTextView = getTicketsDialogView.findViewById<TextView>(R.id.message5_text)
                    val totalPriceTextView = getTicketsDialogView.findViewById<TextView>(R.id.message6_text)

                    adultTicketsTextView.text = getString(R.string.number_of_tickets_for_adults) + selectedItemAdult.toString()
                    childTicketsTextView.text = getString(R.string.number_of_tickets_for_children) + selectedItemChild.toString()
                    cinemaTextView.text = getString(R.string.cinema_summary) + cinemaText.text
                    dateTextView.text = getString(R.string.date_summary) + dateText.text
                    totalPriceTextView.text = getString(R.string.total_price) +
                            ((selectedItemChild + selectedItemAdult) * 20).toString() + "" + getString(R.string.coin)

                    val buyButton = getTicketsDialogView.findViewById<MaterialButton>(R.id.buy_button)

                    buyButton?.setOnClickListener(){
                        getTicketsDialog.dismiss()
                        val buyDialogBuilder = AlertDialog.Builder(this)
                        val buyDialogView = layoutInflater.inflate(R.layout.buy_dialog, null)
                        buyDialogBuilder.setView(buyDialogView)
                        val buyDialog = buyDialogBuilder.create()

                        buyDialogView.findViewById<TextView>(R.id.message2_text).text = adultTicketsTextView.text
                        buyDialogView.findViewById<TextView>(R.id.message3_text).text = childTicketsTextView.text
                        buyDialogView.findViewById<TextView>(R.id.message4_text).text = cinemaTextView.text
                        buyDialogView.findViewById<TextView>(R.id.message5_text).text = dateTextView.text

                        val newBuyingButton = buyDialogView.findViewById<MaterialButton>(R.id.buy_button)
                        val exitButton = buyDialogView.findViewById<MaterialButton>(R.id.exit_button)
                        newBuyingButton?.setOnClickListener {
                            autoCompleteTextViewKids.setText("")
                            autoCompleteTextViewAdult.setText("")
                            selectedItemChild = 0
                            selectedItemAdult = 0
                            buyDialog.dismiss()
                            cinemaText.text = getString(R.string.cinema_text)
                            dateText.text = getString(R.string.not_selected_a_date_yet)
                        }
                        exitButton?.setOnClickListener {
                            finish()
                        }
                        buyDialog.show()
                    }

                    val exitButton = getTicketsDialogView.findViewById<MaterialButton>(R.id.exit_button)
                    exitButton?.setOnClickListener {
                        getTicketsDialog.dismiss()
                    }
                    getTicketsDialog.show()
                }
            }
        }
    }